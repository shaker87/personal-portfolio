import React from 'react'

export default function ProductModal() {
  return (
    <div>
      
    </div>
  )
}
