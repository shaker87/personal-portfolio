import React from 'react'

export default function UpdateProduct() {
  return (
    <div>
      
    </div>
  )
}
