import React from 'react'
// import AddToCartButton from '../misc/AddToCartButton'
// import QuantityDropdownButton from '../misc/QuantityDropdownButton'
// import RelatedItems from '../misc/RelatedItems'
// import ProductDisplay from '../products/ProductDisplay'
// import ViewOneProduct from './ViewOneProduct'

export default function TEST() {

  return (
    <div>
      {/* <AddToCartButton title="Add to Cart"/> */}
      {/* <QuantityDropdownButton /> */}
      {/* <RelatedItems imgUrl="https://images.unsplash.com/photo-1534109165916-7878ad66d5eb?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80" title="Red Shirt" price="50"/> */}
      {/* <ViewOneProduct /> */}
      {/* <ProductDisplay /> */}
    </div>
  )
}
