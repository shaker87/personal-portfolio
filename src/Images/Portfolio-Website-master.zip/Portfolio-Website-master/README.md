# Portfolio-Website
GitHub Repo for Portfolio website. 

Features: Deploying all projects, minus one which is the Tweet Me project (coming soon). Implementating EmailJs via React to handle sent emails. Using custom CSS, Bootstap and react-reveal library.
