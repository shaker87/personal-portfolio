import React from 'react';
import HomePage from '../components/HomePage';

const Sections = () => {

    return (
        <>
            <section>
                <HomePage />
            </section>
        </>
    );
};

export default Sections;